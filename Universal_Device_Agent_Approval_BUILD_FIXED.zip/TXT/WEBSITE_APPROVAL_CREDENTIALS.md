# Website-approved device credentials

## New flow
1. A fresh app install sends `POST /devices/register` with `device_name` and `platform`.
2. The server persists a pending registration and returns a random registration ID plus a 256-bit polling secret. Only the SHA-256 hash of that secret is persisted.
3. The owner signs in to the website and sees the request under **Pending approval**.
4. The owner approves for a number of hours, days, months (defined as 30 days), or permanent access, or rejects it.
5. The app polls `GET /devices/registration/{id}` using the polling secret. It receives a device bearer credential only after approval.
6. The bearer credential is saved through the app's existing secure credential store.

## Security and migration
- `POST /devices/pair` and `POST /pairing-codes` return HTTP 410; the old short-lived pairing-code flow cannot bypass approval.
- Pending requests expire after 24 hours. This request window is separate from the approved device's access duration.
- Approved device expiry is checked for device bearer tokens and API-key authentication. A 30-second server sweep removes expired devices and closes their active connections.
- Old persisted devices without `expires_at` remain permanent (grandfathered); no existing paired device is removed by migration.
- The admin website uses existing `ADMIN_TOKEN` session-only browser entry. Keep it private and use HTTPS.
- The server uses the existing persistent JSON state file, so Railway must retain its `/data` volume.

## Duration semantics
- `hours`: integer hours
- `days`: integer days
- `months`: 30 days per month
- `permanent`: no expiry; owner can revoke from the website

## API routes
- `POST /devices/register`
- `GET /devices/registration/{id}` (Bearer polling secret)
- `GET /admin/pending-devices`
- `POST /admin/pending-devices/{id}/approve` with `{ "unit": "days", "amount": 30 }` or `{ "unit": "permanent" }`
- `POST /admin/pending-devices/{id}/reject`
- `POST /admin/devices/{id}/revoke`
