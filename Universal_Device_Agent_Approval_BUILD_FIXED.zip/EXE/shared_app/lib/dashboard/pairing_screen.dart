/// Pairing screen — device request waits for explicit website owner approval.
library;

import 'package:flutter/material.dart';


class PairingScreen extends StatefulWidget {
  /// Pairing code aur user ka chuna hua device name.
  final Future<void> Function(String deviceName) onPaired;
  final String defaultDeviceName;

  const PairingScreen({
    super.key,
    required this.onPaired,
    this.defaultDeviceName = 'My Device',
  });

  @override
  State<PairingScreen> createState() => _PairingScreenState();
}

class _PairingScreenState extends State<PairingScreen> {
  late final TextEditingController _nameController =
      TextEditingController(text: widget.defaultDeviceName);
  bool _loading = true;
  bool _pairing = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _startPairing();
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  // Pairing request is sent after the user enters a device name.
  Future<void> _startPairing() async {
    if (!mounted) return;
    setState(() {
      _loading = false;
      _error = null;
    });
  }

  Future<void> _continue() async {
    final name = _nameController.text.trim();
    if (_pairing) return;
    if (name.isEmpty || name.length > 100) {
      setState(() => _error = 'Device ka naam 1 se 100 characters ke beech likhein');
      return;
    }
    setState(() {
      _pairing = true;
      _error = null;
    });
    try {
      await widget.onPaired(name);
    } finally {
      if (mounted) setState(() => _pairing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pair This Device')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: _loading
              ? const CircularProgressIndicator()
              : Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Item 89: onboarding — pehli baar aane waale ko 3 steps.
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 420),
                      child: Card(
                        child: ExpansionTile(
                          initiallyExpanded: true,
                          leading: Image.asset('assets/brand/logo.png',
                              width: 36, height: 36),
                          title: const Text('Universal Device Agent'),
                          subtitle: const Text('3 steps mein shuru karein'),
                          childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                          expandedAlignment: Alignment.centerLeft,
                          children: const [
                            Text('1. Is device ko ek naam dein. Website par owner ko approval request nazar aayegi.'),
                            SizedBox(height: 8),
                            Text('2. Owner approve karega aur access ki muddat select karega. Approval tak wait karein.'),
                            SizedBox(height: 8),
                            Text('3. Permissions chunein — sirf wahi jo aap dena chahte hain; '
                                'baad mein Permission Center se badal sakte hain.'),
                            SizedBox(height: 8),
                            Text('4. API Keys banayein: har key ka alag, seemit access hota hai.'),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text('Website owner approval required', textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 24),
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 360),
                      child: TextField(
                        controller: _nameController,
                        maxLength: 100,
                        decoration: const InputDecoration(
                          labelText: 'Device name',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    if (_error != null) ...[
                      const SizedBox(height: 8),
                      Text(_error!,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Theme.of(context).colorScheme.error)),
                    ],
                    const SizedBox(height: 16),
                    FilledButton(
                      onPressed: _pairing ? null : _continue,
                      child: _pairing
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2))
                          : const Text('Request website approval'),
                    ),
                    if (_pairing) ...[
                      const SizedBox(height: 12),
                      const Text('Website owner ki approval ka intezar hai. Approve hote hi device connect ho jayega.', textAlign: TextAlign.center),
                    ],
                  ],
                ),
        ),
      ),
    );
  }
}
