# Universal Device Agent — Platform Build Fixes

This source package includes the native and Flutter source corrections identified during Android, Windows x64, and Linux x64 CI builds.

## Permanent source corrections

- Android: resolve the duplicate `RiskLevel` symbol import in the key manager screen and use `android.util.Base64`.
- Windows: use explicit wide-character Win32 window APIs; expose `WndProc` to the translation-unit-local registrar; include Direct3D 11 interop headers and fully qualify the Direct3D 11 ABI interface; include Known Folders headers for `SHGetKnownFolderPath`; define the Windows bundle install directory.
- Linux: use the `libturbojpeg` pkg-config module; define the install bundle directory; include the generated plugin CMake integration and link bundled plugin libraries; add the generated plugin registrant header; include the required C++ string header.

## Preparing native plugin compatibility

Run `flutter pub get` in `shared_app` before platform preparation.

- Linux: run `bash tool/ci/prepare_linux.sh` from `shared_app`.
- Windows: run `powershell -ExecutionPolicy Bypass -File tool/ci/prepare_windows.ps1` from `shared_app`.

The preparation scripts patch plugin files in Flutter's generated plugin cache/symlink only; they do not modify user data.

## Build prerequisites

- Android: JDK 17 and Flutter SDK.
- Windows: Visual Studio 2022 C++ desktop workload and Flutter SDK.
- Linux: Flutter SDK, CMake, Ninja, Clang, GTK 3 development files, libsecret, jsoncpp, PipeWire, X11/XTest, TurboJPEG, and Evolution Data Server development files.

Run `flutter pub get` first, then `flutter build apk --release`, `flutter build windows --release`, or `flutter build linux --release` on the corresponding supported host.
