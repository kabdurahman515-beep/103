$ErrorActionPreference = "Stop"
$AppRoot = (Resolve-Path (Join-Path $PSScriptRoot "../..")).Path
Set-Location $AppRoot

# Run after flutter pub get so the plugin symlink exists.
$Plugin = "windows/flutter/ephemeral/.plugin_symlinks/flutter_secure_storage_windows/windows/flutter_secure_storage_windows_plugin.cpp"
$PluginCmake = "windows/flutter/ephemeral/.plugin_symlinks/flutter_secure_storage_windows/windows/CMakeLists.txt"

if (!(Test-Path $Plugin)) {
  throw "flutter_secure_storage_windows C++ source not found. Run flutter pub get first."
}
if (!(Test-Path $PluginCmake)) {
  throw "flutter_secure_storage_windows CMakeLists.txt not found. Run flutter pub get first."
}

$Source = Get-Content $Plugin -Raw
$Source = $Source.Replace("WIN32_FIND_DATAA", "WIN32_FIND_DATAW")
$Source = $Source.Replace("FindFirstFileA", "FindFirstFileW")
$Source = $Source.Replace("FindNextFileA", "FindNextFileW")
$Source = $Source.Replace("DeleteFileA", "DeleteFileW")
$Source = $Source.Replace("GetFileAttributesA", "GetFileAttributesW")
Set-Content -Path $Plugin -Value $Source -NoNewline

$Cmake = Get-Content $PluginCmake -Raw
if ($Cmake -notmatch "add_compile_definitions\(UNICODE _UNICODE\)") {
  Add-Content -Path $PluginCmake -Value "`nadd_compile_definitions(UNICODE _UNICODE)`n"
}

Write-Host "Windows secure-storage plugin compatibility prepared."
