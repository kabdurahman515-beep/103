#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$APP_ROOT"

# flutter pub get must have run first so the plugin symlinks/cache exist.
PLUGIN_INCLUDE="$(find "${PUB_CACHE:-$HOME/.pub-cache}/hosted/pub.dev" \
  -type d -path '*/flutter_secure_storage_linux-*/linux/include/flutter_secure_storage_linux' \
  -print -quit 2>/dev/null || true)"

if [[ -z "$PLUGIN_INCLUDE" ]]; then
  echo "ERROR: flutter_secure_storage_linux public headers were not found. Run flutter pub get first." >&2
  exit 1
fi

mkdir -p linux/flutter/flutter_secure_storage_linux
cp -a "$PLUGIN_INCLUDE/." linux/flutter/flutter_secure_storage_linux/

# Keep the generated registrant's include path stable for this custom runner.
if ! grep -Fq 'include_directories("${CMAKE_CURRENT_SOURCE_DIR}/flutter")' linux/CMakeLists.txt; then
  sed -i '/^project(/a include_directories("${CMAKE_CURRENT_SOURCE_DIR}/flutter")' linux/CMakeLists.txt
fi

# The custom app launcher uses std::string.
if ! grep -Fq '#include <string>' linux/app_launcher_manager.cc; then
  sed -i '1i#include <string>' linux/app_launcher_manager.cc
fi

# Ensure the generated plugin registrant header is included by the app entrypoint.
if ! grep -Fq '#include "flutter/generated_plugin_registrant.h"' linux/my_application.cc; then
  sed -i '/#include "my_application.h"/a #include "flutter/generated_plugin_registrant.h"' linux/my_application.cc
fi

echo "Linux plugin headers and generated registrant prepared."
