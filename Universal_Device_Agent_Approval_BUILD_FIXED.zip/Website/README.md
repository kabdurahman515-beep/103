# Control101 website — owner approval build

Upload this folder's `index.html` to the existing Netlify site (or upload the standalone website ZIP contents).

Set the backend URL to `https://102-production.up.railway.app` and sign in with the backend's `ADMIN_TOKEN` (32+ random characters). Do not put the admin token in source code or a public environment variable.

The Devices panel now includes Pending approval. Approve a request for hours, days, months (30 days each), or permanent access. Use Revoke access to remove an existing device.
